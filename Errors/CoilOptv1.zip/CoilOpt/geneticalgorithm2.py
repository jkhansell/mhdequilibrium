import numpy as np

def probfunc(Imutprob, Nbred): 
    return Imutprob*np.exp(-Nbred)

class GenAlg(object):

    def __init__(self, I, ngenes, kcoef, Rred, mutprobfunc = probfunc, Ipopsize = 30, Fpopsize = 10, dpopsize = 5,
                PXcross = 0.85, Imutprob = 0.9, Rabs=0.0001):
        self.I = I
        self.Ipopsize = Ipopsize
        self.Fpopsize = Fpopsize
        self.dpopsize = dpopsize
        self.ngenes = ngenes
        self.PXcross = PXcross
        self.kcoef = kcoef
        self.Imutprob = Imutprob
        self.mutprobfunc = mutprobfunc
        self.Rred = Rred
        self.Rabs = Rabs
        self.maxiter = ngenes*5


    def normalize_params(self, p):
        phi = self.I[1]
        plo = self.I[0]
        pnorm = (p-plo)/(phi-plo)
        return pnorm

    def denormalize_params(self, pnorm):
        phi = self.I[1]
        plo = self.I[0]
        p = (phi-plo)*pnorm + plo
        return p

    def pop_generation(self, npop, ngenes,epsilon, I):
        normeps = self.normalize_params(epsilon, I)
        pop = np.zeros((npop, ngenes))
        pop[0] = np.random.rand(ngenes)
        i = 1
        while i < npop: 
            poptemp = np.random.rand(ngenes)
            truthvect = np.zeros((i+1))
            for k in range(i+1):
                ds = np.sqrt(np.sum((poptemp-pop[k])**2))
                if ds >= normeps: 
                    truthvect[k] = True
            
            if truthvect.all(): 
                pop[i] = poptemp 
                i += 1 
        return pop

    def cost_eval(self, costfunc,pop, I):
        npop = len(pop)
        poptemp = self.denormalize_params(pop, I)
        costvect = np.zeros(npop)
        for i in range(npop):
            costvect[i] = costfunc(poptemp[i])
        return costvect

    def selection(self, pop, I, nparents):
        costvect = self.cost_eval(pop, I)**2
        total = np.sum(costvect)
        pievect = costvect/total
        pievect = np.sort(pievect)
        inds = np.argsort(pievect)
        parents = []
        for j in range(nparents):
            randnum = np.random.rand()
            p = 0
            i = 0
            while p < randnum: 
                p += pievect[i]
                i += 1

            parents.append(pop[inds[i]])
        
        return np.array(parents)

    def recombination(pop, parents):

        nchildren = len(pop)-len(parents)
        newpop = parents.copy()

        for i in range(nchildren): 
            ind1 = np.random.randint(0, len(parents))
            ind2 = np.random.randint(0, len(parents))

            child1 = parents[ind1]
            child2 = parents[ind2]

            indchange = np.random.randint(0, len(child1))

            child1[indchange:-1] = child2[indchange:-1]
            child2[indchange:-1] = child1[indchange:-1]

            M = np.random.randint(1,1001)
        
            dx1 = child1[indchange]/M
            dx2 = child2[indchange]/M

            child1[indchange] += dx2 
            child2[indchange] += dx1
        
            if np.random.rand() > 0.5: 
                newpop = np.append(newpop, child1, axis = 0)
            else: 
                newpop = np.append(newpop, child2, axis = 0)

        return newpop 

    def mutation(pop, mutprob, h, s):
        
        probs = np.random.rand(len(pop))

        for i in range(len(probs)): 
            if probs[i] < mutprob:
                randind = np.random.randint(0,len(pop[i]), size=s)
                dx = np.random.rand(s)*h
                pop[i, randind] += dx
        
        return pop

    def initialization(self):
        
        Rneigh = self.npop*self.ngenes
        delta = self.I[1] - self.I[0] 
        self.epsilon = delta/Rneigh
        self.maxgen = self.ngenes


