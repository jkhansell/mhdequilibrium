#ifndef PARTICLEMESH_H
#define PARTICLEMESH_H


#include <AMReX_MultiFabUtil.H>
#include "utils.h"

using namespace amrex;

namespace ParticleMeshFuncs
{
    void gather_fields
    (
        const Real3& position, 
        const Array4<const Real>& Bx,
        const Array4<const Real>& By, 
        const Array4<const Real>& Bz,
        const Array4<const Real>& Jacobian,
        Real3& Bp,
        Vector<Real>& jacobianp,
        const GpuArray<Real, AMREX_SPACEDIM>& plo,
        const GpuArray<Real, AMREX_SPACEDIM>& dxi
    );
}

#endif

/*
for (int iK = 0; iK < 4; ++iK)
            {
                ParticleMeshFuncs::gather_fields
                (
                    temppos,
                    iBx, iBy, iBz,
                    ijacobian, Bp, jacobianp,
                    plo, dxi
                );

                K[iK] = K_calc(Bp, jacobianp, q, m, tempvpar, mu[i]);

                tempvpar = vpar[i] + dt_coefs[iK]*dt*get<0>(K[iK]);
                temppos = pos + dt_coefs[iK]*dt*get<1>(K[iK]);

                domain_check = checkparticledomain(R0, a, temppos);

                if (domain_check)
                {
                    Print() << "Particle left reactor.\n"; 
                    particles.erase(particles.begin()+i,particles.begin()+i+1);
                }

                if (pti.numParticles() == 0)
                {
                    Print() << "No more particles left in the device. \n ";
                    return false;
                }
            }
*/