#include <AMReX_REAL.H>
#include "Prob.h"
#include "Particles.h"

using namespace amrex; 

void init_values(Real3& Bp, const Vector<Real>& init_velocity, Real3& pos,
                 Real& magvpar, 
                 Real& mu, Real q, Real m)
{
    Real3 vel = {init_velocity[0], 
                 init_velocity[1],
                 init_velocity[2]};
                 
    Real Bmag = mag(Bp);
    Real3 bhat = Bp/Bmag;
    Real vpar_abs = dot(bhat, vel);
    Real3 vpar = vpar_abs*bhat;
    Real3 vperp = vel - vpar;
    Real Omega = q*Bmag/m;
    Real3 rho = cross(bhat, vperp)/Omega;
    Real mu_part = m*dot(vperp,vperp)/(2*Bmag);
    pos += -1.*rho;
    magvpar = vpar_abs;
    mu = mu_part;
}


Tuple<Real, Real3>
K_calc
(
    Real3 Bp,
    Vector<Real> jacobianp,
    const Real charge, const Real mass,
    const Real& magvpar, Real& mu
)
{    
    Real magBp = mag(Bp);
    Real3 gradB;
    
    // Derivatives
    
    Real dBxdx = jacobianp[0]; Real dBxdy = jacobianp[1]; Real dBxdz = jacobianp[2];
    Real dBydx = jacobianp[3]; Real dBydy = jacobianp[4]; Real dBydz = jacobianp[5];
    Real dBzdx = jacobianp[6]; Real dBzdy = jacobianp[7]; Real dBzdz = jacobianp[8];

    gradB[0] = (Bp[0]*dBxdx+Bp[1]*dBydx+Bp[2]*dBzdx)/magBp;
    gradB[1] = (Bp[0]*dBxdy+Bp[1]*dBydy+Bp[2]*dBzdy)/magBp;
    gradB[2] = (Bp[0]*dBxdz+Bp[1]*dBydz+Bp[2]*dBzdz)/magBp;

    Real dbxdx = (dBxdx*magBp-Bp[0]*gradB[0])/(magBp*magBp);
    Real dbxdy = (dBxdy*magBp-Bp[0]*gradB[1])/(magBp*magBp);
    Real dbxdz = (dBxdz*magBp-Bp[0]*gradB[2])/(magBp*magBp);

    Real dbydx = (dBydx*magBp-Bp[1]*gradB[0])/(magBp*magBp);
    Real dbydy = (dBydy*magBp-Bp[1]*gradB[1])/(magBp*magBp);
    Real dbydz = (dBydz*magBp-Bp[1]*gradB[2])/(magBp*magBp);

    Real dbzdx = (dBzdx*magBp-Bp[2]*gradB[0])/(magBp*magBp);
    Real dbzdy = (dBzdy*magBp-Bp[2]*gradB[1])/(magBp*magBp);
    Real dbzdz = (dBzdz*magBp-Bp[2]*gradB[2])/(magBp*magBp);

    Real3 unitB = Bp/magBp;
    
    Real3 curlb;
    curlb[0] = (mass*magvpar/charge)*(dbzdy-dbydz);
    curlb[1] = (mass*magvpar/charge)*(dbxdz-dbzdx);
    curlb[2] = (mass*magvpar/charge)*(dbydx-dbxdy);

    Real3 B_eff = Bp+curlb;
    Real B_effpar = dot(B_eff,unitB);
    Real vpardot = -(mu/(mass*B_effpar))*dot(B_eff, gradB);

    /*
    Real3 nablapar;

    nablapar[0] = unitB[0]*dbxdx+unitB[1]*dbxdy+unitB[2]*dbxdz; 
    nablapar[1] = unitB[0]*dbydx+unitB[1]*dbydy+unitB[2]*dbydz; 
    nablapar[2] = unitB[0]*dbzdx+unitB[1]*dbzdy+unitB[2]*dbzdz; 

    Real3 RS = (mu/mass)*gradB + magvpar*magvpar*nablapar;
    Real3 LS = (mass/(charge*B_effpar))*unitB;
    
    Real3 Xdot = magvpar*unitB+cross(LS,RS);
    */

    Real3 Xdot = (magvpar/B_effpar)*B_eff-(mu/(charge*B_effpar))*cross(gradB, unitB);

    Tuple<Real, Real3> advance = {vpardot, Xdot};

    return advance;
}

void 
derivative_calculation
(
    int i, int j, int k,
    const Array4<Real>& Bx, 
    const Array4<Real>& By, 
    const Array4<Real>& Bz,
    const Array4<Real>& jacobian,
    const GpuArray<Real, AMREX_SPACEDIM> dx
)
{
    jacobian(i,j,k,0) = (Bx(i+1,j,k)-Bx(i-1,j,k))/(2*dx[0]);
    jacobian(i,j,k,1) = (Bx(i,j+1,k)-Bx(i,j-1,k))/(2*dx[1]);
    jacobian(i,j,k,2) = (Bx(i,j,k+1)-Bx(i,j,k-1))/(2*dx[2]);

    jacobian(i,j,k,3) = (By(i+1,j,k)-By(i-1,j,k))/(2*dx[0]);
    jacobian(i,j,k,4) = (By(i,j+1,k)-By(i,j-1,k))/(2*dx[1]);
    jacobian(i,j,k,5) = (By(i,j,k+1)-By(i,j,k-1))/(2*dx[2]);

    jacobian(i,j,k,6) = (Bz(i+1,j,k)-Bz(i-1,j,k))/(2*dx[0]);
    jacobian(i,j,k,7) = (Bz(i,j+1,k)-Bz(i,j-1,k))/(2*dx[1]);
    jacobian(i,j,k,8) = (Bz(i,j,k+1)-Bz(i,j,k-1))/(2*dx[2]);
}