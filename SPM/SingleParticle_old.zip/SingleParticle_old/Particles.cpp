// standard c++ includes
#include <iostream>
#include <fstream>

#include "Particles.h"
#include "utils.h"
#include "ParticleMesh.h"
#include "Prob.h"

using namespace amrex;

SPParticleContainer::SPParticleContainer
(
    const Geometry& geom, 
    const DistributionMapping& dmap, 
    const BoxArray& ba, 
    const Real charge, 
    const Real mass, 
    const Real mpw
)
    : ParticleContainer<PIdx::nattribs,0,0,0>(geom, dmap, ba), q(charge), m(mass)
{}

void SPParticleContainer::InitParticles(const int num_particles)
{
    const int lev = 0; 
    const auto dx = Geom(lev).CellSizeArray();
    const auto plo = Geom(lev).ProbLoArray();
    const auto phi = Geom(lev).ProbHiArray();

    for (MFIter mfi = MakeMFIter(lev); mfi.isValid(); ++mfi)
    {
        auto& particles = GetParticles(lev);
        auto& particle_tile = particles[std::make_pair(mfi.index(), mfi.LocalTileIndex())];

        const Box& bx = mfi.tilebox();

        //AMREX_PARALLEL_FOR_1D(num_particles, i, 
        for (int i = 0; i < num_particles; ++i)
        {
            int procID = ParallelDescriptor::MyProc();
            ParticleType p;
            p.id() = ParticleType::NextID(); 
            p.cpu() = procID; 
            p.pos(0) = 0.29;
            p.pos(1) = 0.0;
            p.pos(2) = 0.0;
            p.rdata(PIdx::vpar) = 0.0;
            p.rdata(PIdx::mu) = 0.0;
            
            particle_tile.push_back(p); 
        }
    }
    Redistribute();
}

bool SPParticleContainer::PushParticleTrajectory
(
    const Array<MultiFab*, AMREX_SPACEDIM>& Bfield,
    const MultiFab& Jacobian, const Vector<Real>& init_velocity,
    const Real dt, const int iStep, const Real R0, const Real a,
    const int plotint
)
{
    BL_PROFILE("PushParticleTrajectory()");
    const int lev = 0; 
    const auto dxi = Geom(lev).InvCellSizeArray();
    const auto plo = Geom(lev).ProbLoArray();
    const auto phi = Geom(lev).ProbHiArray();

    for (SPPartIter pti (*this, lev); pti.isValid(); ++pti)
    {
        const int np = pti.numParticles(); 
        auto& particles = pti.GetArrayOfStructs();
        auto& partattrbs = pti.GetStructOfArrays(); 

        const auto& iBx = (*Bfield[0]).array(pti); 
        const auto& iBy = (*Bfield[1]).array(pti); 
        const auto& iBz = (*Bfield[2]).array(pti);

        const auto& ijacobian = Jacobian.array(pti);

        for (int i = 0; i < np; ++i)
        {

            ParticleType& p = particles[i];
            Real3 pos = {p.pos(0), p.pos(1), p.pos(2)};
            Real3 temppos; 
            Real tempvpar;
            Real3 gradB;
            Real3 Bp;
            Vector<Real> jacobianp(9);
            Vector<Tuple<Real, Real3>> K(4);
            Vector<Real> dt_coefs = {0.5, 0.5, 1, 0};
            bool domain_check;

            ParticleMeshFuncs::gather_fields
            (
                pos,
                iBx, iBy, iBz,
                ijacobian, Bp, jacobianp,
                plo, dxi
            );

            if (iStep == 0)
            {
                init_values(Bp, init_velocity, pos, p.rdata(PIdx::vpar), p.rdata(PIdx::mu), q, m);
            }

            tempvpar = p.rdata(PIdx::vpar);
            temppos = pos;

            for (int iK = 0; iK < 4; ++iK)
            {
                domain_check = checkparticledomain(R0, a, temppos);
                if (domain_check)
                {
                    Print() << "Particle left reactor.\n"; 
                    particles.erase(particles.begin()+i,particles.begin()+i+1);
                }

                if (pti.numParticles() == 0)
                {
                    Print() << "No more particles left in the device. \n ";
                    return false;
                }

                ParticleMeshFuncs::gather_fields
                (
                    temppos,
                    iBx, iBy, iBz,
                    ijacobian, Bp, jacobianp,
                    plo, dxi
                );     

                K[iK] = K_calc(Bp, jacobianp, q, m, tempvpar, p.rdata(PIdx::mu));

                tempvpar = p.rdata(PIdx::vpar) + dt_coefs[iK]*dt*get<0>(K[iK]);
                temppos = pos + dt_coefs[iK]*dt*get<1>(K[iK]);

            }

            Real vpartot = dt*(get<0>(K[0])+2*get<0>(K[1])+2*get<0>(K[2])+get<0>(K[3]))/6.;
            Real3 Xdottot = dt*(get<1>(K[0])+2.*get<1>(K[1])+2.*get<1>(K[2])+get<1>(K[3]))/6.;

            //Print() << "position: " << pos(0) << ", "<< pos(1) << ", "<< pos(2) << "\n";

            p.rdata(PIdx::vpar) += vpartot;
            pos += Xdottot;
            
            Real vtot = p.rdata(PIdx::vpar)*p.rdata(PIdx::vpar)+2*p.rdata(PIdx::mu)*mag(Bp)/m;
            Real Energy = ENERGY*m*vtot/2;

            p.pos(0) = pos(0);
            p.pos(1) = pos(1);
            p.pos(2) = pos(2);

            //Print() << "position: " << pos(0) << ", "<< pos(1) << ", "<< pos(2) << "\n";
            //Print() << "vpar: " << vpar[i] << "\n";
            
            if (iStep % plotint == 0)
            {
                Print() << "Energía de la partícula: "<< Energy <<"\n";
                std::string filename = "trajectories/particle"+std::to_string(i)+".txt";
                std::ofstream myfile(filename, std::ios_base::app); 
                if (myfile.is_open())
                {
                    myfile << std::scientific; 
                    myfile <<iStep<<"\t"<<dt*iStep<<"\t"<<p.pos(0)<<"\t"<<p.pos(1)<<"\t"<<p.pos(2)<<"\t"<<p.rdata(PIdx::vpar)<<"\t"<<p.rdata(PIdx::mu)<<"\t"<<Bp(0)<<"\t"<<Bp(1)<<"\t"<<Bp(2)<<"\n";
                }
            }
            
        }
    }
    Redistribute();
    return true;
}

bool SPParticleContainer::checkparticledomain
(
    const Real R0,
    const Real a,
    const Real3 pos
)
{
    Real R = sqrt(pow(pos(0),2)+pow(pos(1),2)); 
    Real r = sqrt(pow(R-R0,2)+pow(pos(2),2));

    if (r > a){return true;}
    else {return false;}
}
