#ifndef PARTICLES_H
#define PARTICLES_H

#include <AMReX_Particles.H>

#include "utils.h"


using namespace amrex; 

struct PIdx
{
    enum{
        ux = 0, 
        uy, uz, w, vpar, mu,
        nattribs
    };
};

class SPPartIter
    : public amrex::ParIter<PIdx::nattribs,0,0,0>
{
    public: 
    
    using amrex::ParIter<PIdx::nattribs,0,0,0>::ParIter;

    //    EMParIter (ContainerType& pc, int level);

    const RealVector& GetAttribs (int comp) const {
        return GetStructOfArrays().GetRealData(comp);
    }

    RealVector& GetAttribs (int comp) {
        return GetStructOfArrays().GetRealData(comp);
    }
};

class SPParticleContainer 
    : public amrex::ParticleContainer<PIdx::nattribs,0,0,0>
{
    public:

        SPParticleContainer(const Geometry& geom, 
                            const DistributionMapping& dmap, 
                            const BoxArray& ba, 
                            const Real charge, 
                            const Real mass, 
                            const Real mpw); 

        void InitParticles(const int num_particles);


        // this code needs to be compiled in 3D
        bool PushParticleTrajectory(const Array<MultiFab*, AMREX_SPACEDIM>& Bfield,
                                    const MultiFab& Jacobian, const Vector<Real>& init_velocity,
                                    const Real dt, const int iStep, const Real R0, const Real a,
                                    const int plotint);

        // checks particle's domain in periodic conditions
        bool checkparticledomain
        (
            const Real R0,
            const Real a,
            const Real3 pos
        );


    private: 

        Real q;
        Real m;

};


#endif

